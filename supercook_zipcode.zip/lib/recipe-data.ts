export interface RecipeInstruction {
  image: string
  text: string
  clickableTerms?: { term: string; positions: [number, number] }[]
}

export interface RecipeStep {
  title: string
  subtitle: string
  instructions: RecipeInstruction[]
}

export interface Recipe {
  id: string
  name: string
  category: string
  image: string
  time: string
  servings: number
  rating: number
  isFavorite: boolean
  ingredients: string[]
  steps: RecipeStep[]
}

// First 2 recipes in each category use Unsplash URLs, last 2 use placeholders
export const recipes: Recipe[] = [
  // ============================================
  // STUDENT FRIENDLY (4 recipes)
  // ============================================

  // Recipe 1: Nasi Goreng Biasa (with Unsplash images)
  {
    id: "nasi-goreng-biasa",
    name: "Nasi Goreng Biasa",
    category: "Student Friendly",
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&q=80",
    time: "15 mins",
    servings: 1,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "2 cups cooked white rice (day-old rice works best)",
      "2 tablespoons cooking oil",
      "2 cloves garlic, minced",
      "1 egg",
      "2 tablespoons soy sauce",
      "1 tablespoon kecap manis (sweet soy sauce)",
      "Salt and pepper to taste",
      "Spring onions for garnish (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Heat oil and sauté garlic",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1506368249639-73a05d6f6488?w=800&q=80",
            text: "Heat oil in a wok or large pan over medium-high heat. Add minced garlic and sauté until fragrant, about 30 seconds.",
            clickableTerms: [{ term: "sauté", positions: [67, 72] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add rice and stir-fry",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&q=80",
            text: "Add the cooked rice and break up any clumps. Stir-fry for 3-4 minutes until rice is heated through.",
            clickableTerms: [{ term: "Stir-fry", positions: [48, 56] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Season and add egg",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1617093727343-374698b1b08d?w=800&q=80",
            text: "Push rice to the side, crack an egg into the pan. Scramble the egg, then mix it into the rice. Add soy sauce and kecap manis.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Finish and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1516684732162-798a0062be99?w=800&q=80",
            text: "Stir everything together for 1-2 minutes. Season with salt and pepper. Garnish with spring onions if desired.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Telur Kicap Berlado (with Unsplash images)
  {
    id: "telur-kicap-berlado",
    name: "Telur Kicap Berlado",
    category: "Student Friendly",
    image: "/images/telur-kicap-berlado.jpg",
    time: "12 mins",
    servings: 1,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "2 eggs",
      "2 tablespoons cooking oil",
      "1 onion, sliced",
      "2 cloves garlic, minced",
      "1-2 red chilies, sliced (adjust to taste)",
      "2 tablespoons soy sauce",
      "1 tablespoon tomato sauce",
      "1 teaspoon sugar",
      "Salt to taste",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Fry eggs",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1582169296194-e4d6444c48063?w=800&q=80",
            text: "Heat 1 tablespoon oil in a pan. Fry eggs sunny-side up or to your preference. Remove and set aside.",
            clickableTerms: [{ term: "Fry", positions: [39, 42] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Sauté aromatics",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1599899424587-635dd76c6d8d?w=800&q=80",
            text: "In the same pan, add remaining oil. Sauté sliced onions, garlic, and chilies until fragrant and onions soften, about 3-4 minutes.",
            clickableTerms: [{ term: "Sauté", positions: [39, 44] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Make sauce",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1633436861633-058a9c53da19?w=800&q=80",
            text: "Add soy sauce, tomato sauce, sugar, and salt. Stir well and simmer for 1-2 minutes until sauce thickens slightly.",
            clickableTerms: [{ term: "simmer", positions: [58, 64] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Combine and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1565299585323-38d6b062be99?w=800&q=80",
            text: "Pour the sauce over the fried eggs and serve immediately with rice.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Simple Fried Egg & Soy Sauce Rice (with placeholders)
  {
    id: "simple-fried-egg-soy-sauce-rice",
    name: "Simple Fried Egg & Soy Sauce Rice",
    category: "Student Friendly",
    image: "/images/simple-fried-egg-soy-sauce-rice.jpg",
    time: "8 mins",
    servings: 1,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "1 cup cooked white rice",
      "1-2 eggs",
      "1 tablespoon cooking oil",
      "1-2 tablespoons soy sauce",
      "Sesame oil (optional)",
      "Spring onions for garnish (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Fry the egg",
        instructions: [
          {
            image: "/images/frying-egg-in-pan.jpg",
            text: "Heat oil in a small pan over medium heat. Crack the egg and fry until the edges are crispy and yolk is still runny.",
            clickableTerms: [{ term: "fry", positions: [65, 68] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Prepare rice",
        instructions: [
          {
            image: "/images/rice-in-bowl.jpg",
            text: "Place warm rice in a bowl. Drizzle with soy sauce and mix well.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Assemble and serve",
        instructions: [
          {
            image: "/images/egg-on-rice-bowl.jpg",
            text: "Place the fried egg on top of the rice. Add a few drops of sesame oil and garnish with spring onions if desired. Break the yolk and mix before eating.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Curry Flavoured Maggie (with placeholders)
  {
    id: "curry-flavoured-maggie",
    name: "Curry Flavoured Maggie",
    category: "Student Friendly",
    image: "/images/curry-maggie-noodles.jpg",
    time: "10 mins",
    servings: 1,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "1 packet Maggi curry instant noodles",
      "2 cups water",
      "1 egg",
      "Handful of vegetables (cabbage, carrots, or bok choy)",
      "Curry powder seasoning packet (from noodle pack)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Boil water",
        instructions: [
          {
            image: "/images/boiling-water-pot.jpg",
            text: "Bring 2 cups of water to a boil in a small pot.",
            clickableTerms: [{ term: "boil", positions: [23, 27] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Cook noodles",
        instructions: [
          {
            image: "/images/cooking-instant-noodles.jpg",
            text: "Add the noodles and curry powder packet. Cook for 2-3 minutes, stirring occasionally.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add egg and vegetables",
        instructions: [
          {
            image: "/images/adding-egg-to-noodles.jpg",
            text: "Add vegetables and crack an egg into the pot. Let it poach for 1-2 minutes without stirring for a soft yolk, or stir to scramble.",
            clickableTerms: [{ term: "poach", positions: [58, 63] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve hot",
        instructions: [
          {
            image: "/images/instant-noodles-in-bowl.jpg",
            text: "Transfer to a bowl and serve immediately while hot.",
          },
        ],
      },
    ],
  },

  // ============================================
  // QUICK AND EASY (4 recipes)
  // ============================================

  // Recipe 1: Quick Chicken Stir Fry (with Unsplash images)
  {
    id: "quick-chicken-stir-fry",
    name: "Quick Chicken Stir Fry",
    category: "Quick and Easy",
    image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=800&q=80",
    time: "15 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "300g chicken breast, sliced thin",
      "2 tablespoons cooking oil",
      "3 cloves garlic, minced",
      "1 bell pepper, sliced",
      "1 onion, sliced",
      "2 tablespoons soy sauce",
      "1 tablespoon oyster sauce",
      "1 teaspoon cornstarch mixed with 2 tablespoons water",
      "Salt and pepper to taste",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté chicken",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=800&q=80",
            text: "Heat oil in a wok over high heat. Add chicken slices and sauté for 3-4 minutes until cooked through and lightly browned.",
            clickableTerms: [{ term: "sauté", positions: [58, 63] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add vegetables",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1559774708-96f40f38ebfe?w=800&q=80",
            text: "Add garlic, bell pepper, and onion. Stir-fry for 2-3 minutes until vegetables soften.",
            clickableTerms: [{ term: "Stir-fry", positions: [39, 47] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add sauce",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1627308595171-d1b5d67129c4?w=800&q=80",
            text: "Add soy sauce, oyster sauce, and cornstarch mixture. Toss everything together for 1 minute until sauce thickens.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Season and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&q=80",
            text: "Season with salt and pepper. Serve hot with steamed rice.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Garlic Butter Fried Rice (with Unsplash images)
  {
    id: "garlic-butter-fried-rice",
    name: "Garlic Butter Fried Rice",
    category: "Quick and Easy",
    image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&q=80",
    time: "12 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "3 cups cooked rice (preferably day-old)",
      "3 tablespoons butter",
      "5 cloves garlic, minced",
      "2 eggs",
      "2 tablespoons soy sauce",
      "1 tablespoon oyster sauce",
      "Spring onions, chopped",
      "Salt and pepper to taste",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Melt butter and sauté garlic",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1445939743787-e11eb56519d6b?w=800&q=80",
            text: "Melt butter in a large pan or wok over medium heat. Add minced garlic and sauté until fragrant and golden, about 1-2 minutes.",
            clickableTerms: [{ term: "sauté", positions: [76, 81] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Scramble eggs",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&q=80",
            text: "Push garlic to the side. Crack eggs into the pan and scramble until just cooked.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add rice and stir-fry",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1516684732162-798a0062be99?w=800&q=80",
            text: "Add the rice and break up any clumps. Stir-fry for 3-4 minutes, mixing well with the garlic butter.",
            clickableTerms: [{ term: "Stir-fry", positions: [40, 48] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Season and finish",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1617093727343-374698b1b08d?w=800&q=80",
            text: "Add soy sauce and oyster sauce. Mix well. Season with salt and pepper, then garnish with spring onions.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Thai Basil Chicken (with placeholders)
  {
    id: "thai-basil-chicken",
    name: "Thai Basil Chicken",
    category: "Quick and Easy",
    image: "/images/thai-basil-chicken.jpg",
    time: "18 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "300g ground chicken",
      "2 tablespoons cooking oil",
      "4 cloves garlic, minced",
      "2 red chilies, sliced",
      "1 onion, sliced",
      "2 tablespoons soy sauce",
      "1 tablespoon fish sauce",
      "1 tablespoon oyster sauce",
      "1 teaspoon sugar",
      "1 cup fresh Thai basil leaves",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté aromatics",
        instructions: [
          {
            image: "/images/garlic-chili-cooking.jpg",
            text: "Heat oil in a wok over high heat. Add garlic and chilies, sauté for 30 seconds until fragrant.",
            clickableTerms: [{ term: "sauté", positions: [62, 67] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Cook chicken",
        instructions: [
          {
            image: "/images/ground-chicken-cooking.jpg",
            text: "Add ground chicken and break it up with a spatula. Stir-fry for 4-5 minutes until cooked through.",
            clickableTerms: [{ term: "Stir-fry", positions: [57, 65] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add sauce and basil",
        instructions: [
          {
            image: "/images/basil-leaves-stir-fry.jpg",
            text: "Add onion, soy sauce, fish sauce, oyster sauce, and sugar. Stir-fry for 2 minutes. Turn off heat and add basil leaves, stirring until wilted.",
            clickableTerms: [{ term: "Stir-fry", positions: [60, 68] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "/images/thai-chicken-rice.jpg",
            text: "Serve immediately over steamed jasmine rice with a fried egg on top if desired.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Easy Stir-Fry Noodles (with placeholders)
  {
    id: "easy-stir-fry-noodles",
    name: "Easy Stir-Fry Noodles",
    category: "Quick and Easy",
    image: "/images/easy-stir-fry-noodles.jpg",
    time: "15 mins",
    servings: 2,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "200g egg noodles or rice noodles",
      "2 tablespoons cooking oil",
      "2 cloves garlic, minced",
      "Mixed vegetables (carrots, cabbage, bell peppers)",
      "2 tablespoons soy sauce",
      "1 tablespoon oyster sauce",
      "1 teaspoon sesame oil",
      "Salt and pepper to taste",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Boil noodles",
        instructions: [
          {
            image: "/images/boiling-noodles.jpg",
            text: "Boil noodles according to package instructions until al dente. Drain and set aside.",
            clickableTerms: [
              { term: "Boil", positions: [0, 4] },
              { term: "al dente", positions: [55, 63] },
            ],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Stir-fry vegetables",
        instructions: [
          {
            image: "/images/placeholder.svg?height=400&width=600",
            text: "Heat oil in a wok. Add garlic and vegetables. Stir-fry for 3-4 minutes until slightly softened.",
            clickableTerms: [{ term: "Stir-fry", positions: [49, 57] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Combine noodles and sauce",
        instructions: [
          {
            image: "/images/placeholder.svg?height=400&width=600",
            text: "Add cooked noodles, soy sauce, and oyster sauce. Toss everything together for 2-3 minutes over high heat.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Finish and serve",
        instructions: [
          {
            image: "/images/placeholder.svg?height=400&width=600",
            text: "Drizzle with sesame oil and season with salt and pepper. Serve hot.",
          },
        ],
      },
    ],
  },

  // ============================================
  // ASIAN MENU (4 recipes)
  // ============================================

  // Recipe 1: Teriyaki Chicken Bowl (with Unsplash images)
  {
    id: "teriyaki-chicken-bowl",
    name: "Teriyaki Chicken Bowl",
    category: "Asian Menu",
    image: "https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=800&q=80",
    time: "20 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "300g chicken breast, sliced",
      "2 tablespoons cooking oil",
      "3 tablespoons soy sauce",
      "2 tablespoons honey",
      "1 tablespoon mirin or rice vinegar",
      "1 teaspoon cornstarch mixed with 2 tablespoons water",
      "2 cups cooked white rice",
      "Sesame seeds for garnish",
      "Sliced green onions for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté chicken",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=800&q=80",
            text: "Heat oil in a pan over medium-high heat. Add chicken slices and sauté for 5-6 minutes until cooked through and golden.",
            clickableTerms: [{ term: "sauté", positions: [67, 72] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Make teriyaki sauce",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1475090169767-40ed8d940446?w=800&q=80",
            text: "In a small bowl, mix soy sauce, honey, and mirin. Pour over the chicken.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Simmer and glaze",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1626804475297-41608ea09aeb?w=800&q=80",
            text: "Add cornstarch mixture and simmer for 2-3 minutes, stirring occasionally until sauce thickens and becomes glossy.",
            clickableTerms: [{ term: "simmer", positions: [29, 35] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Assemble bowl",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1580959375944-2c099191d2e5?w=800&q=80",
            text: "Serve chicken and sauce over warm rice. Garnish with sesame seeds and green onions.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Kimchi Fried Rice (with Unsplash images)
  {
    id: "kimchi-fried-rice",
    name: "Kimchi Fried Rice",
    category: "Asian Menu",
    image: "https://images.unsplash.com/photo-1598679253544-2c97992403ea?w=800&q=80",
    time: "15 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "2 cups cooked rice (day-old preferred)",
      "1 cup kimchi, chopped",
      "2 tablespoons kimchi juice",
      "2 tablespoons cooking oil",
      "2 cloves garlic, minced",
      "2 eggs",
      "2 tablespoons soy sauce",
      "1 teaspoon sesame oil",
      "Sesame seeds and spring onions for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté kimchi",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1580870069867-74c02fbb3f0f?w=800&q=80",
            text: "Heat 1 tablespoon oil in a wok over medium-high heat. Add garlic and chopped kimchi. Sauté for 3-4 minutes until kimchi is slightly caramelized.",
            clickableTerms: [{ term: "Sauté", positions: [87, 92] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add rice and stir-fry",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&q=80",
            text: "Add the rice, kimchi juice, and soy sauce. Stir-fry for 3-4 minutes, breaking up clumps and mixing well.",
            clickableTerms: [{ term: "Stir-fry", positions: [48, 56] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Fry eggs",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1582169296194-e4d6444c48063?w=800&q=80",
            text: "In a separate pan, fry 2 eggs sunny-side up with remaining oil until edges are crispy but yolk is runny.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Assemble and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1606557119443-ab6d742eec0a?w=800&q=80",
            text: "Transfer fried rice to plates. Top each with a fried egg. Drizzle with sesame oil and garnish with sesame seeds and spring onions.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Garlic Sesame Tofu (with placeholders)
  {
    id: "garlic-sesame-tofu",
    name: "Garlic Sesame Tofu",
    category: "Asian Menu",
    image: "/images/garlic-sesame-tofu.jpg",
    time: "18 mins",
    servings: 2,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "300g firm tofu, cubed and patted dry",
      "3 tablespoons cooking oil",
      "4 cloves garlic, minced",
      "2 tablespoons soy sauce",
      "1 tablespoon sesame oil",
      "2 tablespoons toasted sesame seeds",
      "1 tablespoon rice vinegar",
      "1 teaspoon sugar",
      "Spring onions for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Pan-fry tofu",
        instructions: [
          {
            image: "/images/garlic-sesame-tofu-step1.jpg",
            text: "Heat 2 tablespoons oil in a non-stick pan over medium-high heat. Add tofu cubes and pan-fry for 6-8 minutes, turning occasionally until all sides are golden and crispy.",
            clickableTerms: [{ term: "pan-fry", positions: [87, 94] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Make garlic sauce",
        instructions: [
          {
            image: "/images/garlic-sesame-tofu-step2.jpg",
            text: "Remove tofu and set aside. Add remaining oil and minced garlic to the pan. Sauté for 30 seconds until fragrant.",
            clickableTerms: [{ term: "Sauté", positions: [80, 85] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Combine and coat",
        instructions: [
          {
            image: "/images/garlic-sesame-tofu-step3.jpg",
            text: "Add soy sauce, sesame oil, rice vinegar, and sugar. Return tofu to pan and toss to coat in sauce. Cook for 1-2 minutes.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Garnish and serve",
        instructions: [
          {
            image: "/images/garlic-sesame-tofu-step4.jpg",
            text: "Sprinkle with toasted sesame seeds and spring onions. Serve hot with steamed rice.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Sambal Sardine Stir-Fry (with placeholders)
  {
    id: "sambal-sardine-stir-fry",
    name: "Sambal Sardine Stir-Fry",
    category: "Asian Menu",
    image: "/images/sambal-sardine-stir-fry.jpg",
    time: "12 mins",
    servings: 2,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "1 can sardines in tomato sauce (425g)",
      "1 tablespoon cooking oil",
      "1 onion, sliced",
      "3 cloves garlic, minced",
      "2 tablespoons sambal paste (adjust to spice preference)",
      "1 tomato, diced",
      "1 tablespoon soy sauce",
      "1 teaspoon sugar",
      "Fresh cilantro for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté aromatics",
        instructions: [
          {
            image: "/images/sambal-sardine-stir-fry-step1.jpg",
            text: "Heat oil in a pan over medium heat. Add sliced onions and minced garlic. Sauté for 2-3 minutes until onions soften and become translucent.",
            clickableTerms: [{ term: "Sauté", positions: [79, 84] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add sambal and tomato",
        instructions: [
          {
            image: "/images/sambal-sardine-stir-fry-step2.jpg",
            text: "Add sambal paste and diced tomato. Sauté for 2 minutes until fragrant and tomato softens.",
            clickableTerms: [{ term: "Sauté", positions: [41, 46] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Simmer sardines",
        instructions: [
          {
            image: "/images/sambal-sardine-stir-fry-step3.jpg",
            text: "Add canned sardines with their sauce, soy sauce, and sugar. Gently simmer for 3-4 minutes, breaking up sardines slightly while stirring.",
            clickableTerms: [{ term: "simmer", positions: [72, 78] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "/images/sambal-sardine-stir-fry-step4.jpg",
            text: "Garnish with fresh cilantro. Serve hot with steamed rice or bread.",
          },
        ],
      },
    ],
  },

  // ============================================
  // WESTERN MENU (4 recipes)
  // ============================================

  // Recipe 1: Creamy Garlic Chicken (with Unsplash images)
  {
    id: "creamy-garlic-chicken",
    name: "Creamy Garlic Chicken",
    category: "Western Menu",
    image: "https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=800&q=80",
    time: "25 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "300g chicken breast, sliced",
      "2 tablespoons butter",
      "6 cloves garlic, minced",
      "1 cup heavy cream or milk",
      "1/2 cup chicken stock",
      "1/2 cup grated Parmesan cheese",
      "1 teaspoon dried Italian herbs",
      "Salt and pepper to taste",
      "Fresh parsley for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Cook chicken",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=800&q=80",
            text: "Season chicken with salt and pepper. Melt 1 tablespoon butter in a pan over medium-high heat. Cook chicken for 5-6 minutes until golden and cooked through. Remove and set aside.",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Sauté garlic",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&q=80",
            text: "In the same pan, melt remaining butter. Add minced garlic and sauté for 1 minute until fragrant and golden.",
            clickableTerms: [{ term: "sauté", positions: [63, 68] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Make cream sauce",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1623428187969-5da2dcea5ebf?w=800&q=80",
            text: "Add cream, chicken stock, Parmesan, and Italian herbs. Stir well and simmer for 3-4 minutes until sauce thickens.",
            clickableTerms: [{ term: "simmer", positions: [78, 84] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Combine and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1632778149955-e80f8ceca2e8?w=800&q=80",
            text: "Return chicken to pan and coat in sauce. Cook for 1-2 minutes. Garnish with parsley and serve with pasta or mashed potatoes.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Classic Mashed Potato with Gravy (with Unsplash images)
  {
    id: "classic-mashed-potato-gravy",
    name: "Classic Mashed Potato with Gravy",
    category: "Western Menu",
    image: "/images/classic-mashed-potato-gravy.jpg",
    time: "30 mins",
    servings: 3,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "4 large potatoes, peeled and cubed",
      "3 tablespoons butter",
      "1/4 cup milk or cream",
      "Salt and pepper to taste",
      "For gravy:",
      "2 tablespoons butter",
      "2 tablespoons flour",
      "1 cup chicken stock",
      "1 tablespoon soy sauce",
      "Salt and pepper to taste",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Boil potatoes",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800&q=80",
            text: "Place potato cubes in a pot of cold salted water. Bring to a boil and cook for 15-20 minutes until fork-tender.",
            clickableTerms: [{ term: "boil", positions: [65, 69] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Mash potatoes",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1564671165093-20688ff1fffa?w=800&q=80",
            text: "Drain potatoes and return to pot. Add butter and milk. Mash until smooth and creamy. Season with salt and pepper.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Make gravy",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1606491048763-a8eef0b98528?w=800&q=80",
            text: "In a small pan, melt butter over medium heat. Add flour and whisk for 1 minute. Gradually add chicken stock and soy sauce, whisking constantly until gravy thickens (about 3-4 minutes).",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1630944082609-f8a5c465c6a5?w=800&q=80",
            text: "Serve mashed potatoes with gravy poured over the top. Season gravy with salt and pepper to taste.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Simple Butter Herb Pasta (with placeholders)
  {
    id: "simple-butter-herb-pasta",
    name: "Simple Butter Herb Pasta",
    category: "Western Menu",
    image: "/images/simple-butter-herb-pasta.jpg",
    time: "15 mins",
    servings: 2,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "200g pasta (spaghetti or fettuccine)",
      "3 tablespoons butter",
      "3 cloves garlic, minced",
      "2 tablespoons mixed dried herbs (basil, oregano, thyme)",
      "1/4 cup grated Parmesan cheese",
      "Salt and pepper to taste",
      "Fresh parsley for garnish",
      "Red pepper flakes (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Boil pasta",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Bring a large pot of salted water to a boil. Add pasta and cook until al dente according to package directions (usually 8-10 minutes). Reserve 1/2 cup pasta water before draining.",
            clickableTerms: [
              { term: "boil", positions: [41, 45] },
              { term: "al dente", positions: [68, 76] },
            ],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Make garlic butter",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "While pasta cooks, melt butter in a large pan over medium heat. Add garlic and dried herbs. Sauté for 1-2 minutes until fragrant.",
            clickableTerms: [{ term: "Sauté", positions: [103, 108] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Toss pasta",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Add drained pasta to the pan with garlic butter. Toss well to coat, adding reserved pasta water if needed to create a silky sauce.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Finish and serve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Remove from heat. Add Parmesan cheese and toss. Season with salt, pepper, and red pepper flakes if desired. Garnish with fresh parsley.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Cheesy Omelette (with placeholders)
  {
    id: "cheesy-omelette",
    name: "Cheesy Omelette",
    category: "Western Menu",
    image: "/images/cheesy-omelette.jpg",
    time: "8 mins",
    servings: 1,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "2 large eggs",
      "2 tablespoons milk",
      "1/4 cup grated cheese (cheddar or your choice)",
      "1 tablespoon butter",
      "Salt and pepper to taste",
      "Fresh herbs for garnish (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Beat eggs",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "In a bowl, beat eggs with milk, salt, and pepper until well combined and slightly frothy.",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Cook omelette",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Melt butter in a non-stick pan over medium heat. Pour in egg mixture and let it cook undisturbed for 1-2 minutes until edges begin to set.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add cheese and fold",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Sprinkle grated cheese over one half of the omelette. When eggs are mostly set but still slightly runny on top, gently fold the omelette in half.",
            clickableTerms: [{ term: "fold", positions: [125, 129] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Finish cooking",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Cook for another minute until cheese melts. Slide onto a plate and garnish with fresh herbs if desired.",
          },
        ],
      },
    ],
  },

  // ============================================
  // VEGETARIAN MENU (4 recipes)
  // ============================================

  // Recipe 1: Stir-Fried Tofu & Vegetables (with Unsplash images)
  {
    id: "stir-fried-tofu-vegetables",
    name: "Stir-Fried Tofu & Vegetables",
    category: "Vegetarian Menu",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80",
    time: "20 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "200g firm tofu, cubed",
      "2 tablespoons cooking oil",
      "Mixed vegetables (bell peppers, carrots, broccoli)",
      "2 tablespoons soy sauce",
      "3 cloves garlic, minced",
      "1 tablespoon oyster sauce (or vegetarian alternative)",
      "1 teaspoon cornstarch mixed with 2 tablespoons water",
      "Sesame seeds for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Pan-fry tofu",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1561177488-5b0f7bbf4952?w=800&q=80",
            text: "Heat 1 tablespoon oil in a wok or large pan. Add tofu cubes and pan-fry for 5-6 minutes until golden on all sides. Remove and set aside.",
            clickableTerms: [{ term: "pan-fry", positions: [67, 74] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Stir-fry vegetables",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80",
            text: "Add remaining oil to the pan. Add garlic and vegetables. Stir-fry for 4-5 minutes until vegetables begin to soften but still crisp.",
            clickableTerms: [{ term: "Stir-fry", positions: [59, 67] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add sauce",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1547592166-2f38ce420c8a?w=800&q=80",
            text: "Return tofu to pan. Add soy sauce, oyster sauce, and cornstarch mixture. Toss everything together for 1-2 minutes until sauce thickens.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Garnish and serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&q=80",
            text: "Sprinkle with sesame seeds and serve hot with steamed rice.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Sweet Soy Glazed Tempeh (with Unsplash images)
  {
    id: "sweet-soy-glazed-tempeh",
    name: "Sweet Soy Glazed Tempeh",
    category: "Vegetarian Menu",
    image: "/images/sweet-soy-glazed-tempeh.jpg",
    time: "18 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "200g tempeh, sliced",
      "2 tablespoons cooking oil",
      "3 tablespoons kecap manis (sweet soy sauce)",
      "1 tablespoon regular soy sauce",
      "2 cloves garlic, minced",
      "1 teaspoon ginger, minced",
      "1 tablespoon lime juice",
      "1 teaspoon chili flakes (optional)",
      "Spring onions for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Fry tempeh",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=800&q=80",
            text: "Heat oil in a pan over medium-high heat. Add tempeh slices and fry for 3-4 minutes per side until golden and crispy.",
            clickableTerms: [{ term: "fry", positions: [67, 70] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Sauté aromatics",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=800&q=80",
            text: "Push tempeh to the side. Add garlic and ginger to the pan and sauté for 30 seconds until fragrant.",
            clickableTerms: [{ term: "sauté", positions: [62, 67] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add glaze",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1626804475297-41608ea09aeb?w=800&q=80",
            text: "Add kecap manis, soy sauce, lime juice, and chili flakes if using. Toss tempeh in the sauce and cook for 2 minutes until glazed.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&q=80",
            text: "Transfer to a plate and garnish with spring onions. Serve with rice and vegetables.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Vegetable Curry (with placeholders)
  {
    id: "vegetable-curry",
    name: "Vegetable Curry",
    category: "Vegetarian Menu",
    image: "/images/vegetable-curry.jpg",
    time: "25 mins",
    servings: 3,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "2 tablespoons cooking oil",
      "1 onion, diced",
      "3 cloves garlic, minced",
      "1 tablespoon curry powder",
      "Mixed vegetables (potatoes, carrots, peas, cauliflower)",
      "1 can (400ml) coconut milk",
      "1 cup vegetable stock",
      "Salt to taste",
      "Fresh cilantro for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Sauté aromatics",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Heat oil in a large pot over medium heat. Add diced onion and garlic. Sauté for 3-4 minutes until onion softens.",
            clickableTerms: [{ term: "Sauté", positions: [71, 76] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add curry powder",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Add curry powder and stir for 1 minute until fragrant.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Simmer with vegetables",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Add vegetables, coconut milk, and vegetable stock. Bring to a boil, then reduce heat and simmer for 15-20 minutes until vegetables are tender.",
            clickableTerms: [{ term: "simmer", positions: [108, 114] }],
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Finish and serve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Season with salt to taste. Garnish with fresh cilantro and serve with rice or naan bread.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Mushroom Garlic Noodles (with placeholders)
  {
    id: "mushroom-garlic-noodles",
    name: "Mushroom Garlic Noodles",
    category: "Vegetarian Menu",
    image: "/images/mushroom-garlic-noodles.jpg",
    time: "15 mins",
    servings: 2,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "200g noodles (any type)",
      "2 tablespoons butter or oil",
      "200g mushrooms, sliced",
      "4 cloves garlic, minced",
      "2 tablespoons soy sauce",
      "1 tablespoon oyster sauce (or vegetarian alternative)",
      "1 teaspoon sesame oil",
      "Spring onions and sesame seeds for garnish",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Cook noodles",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Cook noodles according to package instructions until al dente. Drain and set aside.",
            clickableTerms: [{ term: "al dente", positions: [52, 60] }],
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Sauté mushrooms",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Heat butter in a large pan or wok. Add sliced mushrooms and sauté for 4-5 minutes until golden brown.",
            clickableTerms: [{ term: "sauté", positions: [64, 69] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add garlic and sauce",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Add minced garlic and cook for 1 minute. Add soy sauce, oyster sauce, and sesame oil. Stir well.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Combine and serve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Add cooked noodles to the pan and toss everything together for 1-2 minutes. Garnish with spring onions and sesame seeds.",
          },
        ],
      },
    ],
  },

  // ============================================
  // DESSERT MENU (4 recipes)
  // ============================================

  // Recipe 1: Honey Banana Pancake (with Unsplash images)
  {
    id: "honey-banana-pancake",
    name: "Honey Banana Pancake",
    category: "Dessert Menu",
    image: "https://images.unsplash.com/photo-1506084868230-bb9d95c24759?w=800&q=80",
    time: "15 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "1 cup all-purpose flour",
      "1 tablespoon sugar",
      "1 teaspoon baking powder",
      "1 egg",
      "3/4 cup milk",
      "2 tablespoons melted butter",
      "1 ripe banana, sliced",
      "Honey for drizzling",
      "Butter for cooking",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Make batter",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1565299543923-37dd37887442?w=800&q=80",
            text: "In a bowl, mix flour, sugar, and baking powder. In another bowl, whisk egg, milk, and melted butter. Combine wet and dry ingredients until just mixed (some lumps are okay).",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Cook pancakes",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1554520735-0a6b8b6ce8b7?w=800&q=80",
            text: "Heat a non-stick pan over medium heat and add a little butter. Pour 1/4 cup batter for each pancake. Cook until bubbles form on surface (about 2 minutes), then flip and cook 1-2 minutes more.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add banana",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1528207776546-969b307036a3?w=800&q=80",
            text: "While second side cooks, place banana slices on top of pancake.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve with honey",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800&q=80",
            text: "Stack pancakes on a plate. Drizzle generously with honey and serve warm.",
          },
        ],
      },
    ],
  },

  // Recipe 2: Milo Mug Cake (with Unsplash images)
  {
    id: "milo-mug-cake",
    name: "Milo Mug Cake",
    category: "Dessert Menu",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80",
    time: "5 mins",
    servings: 1,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "4 tablespoons all-purpose flour",
      "3 tablespoons Milo powder",
      "2 tablespoons sugar",
      "1/4 teaspoon baking powder",
      "1 egg",
      "3 tablespoons milk",
      "2 tablespoons cooking oil",
      "Vanilla extract (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Mix dry ingredients",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1571115177098-24ec442ed20d?w=800&q=80",
            text: "In a microwave-safe mug, combine flour, Milo powder, sugar, and baking powder. Mix well.",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Add wet ingredients",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=800&q=80",
            text: "Add egg, milk, oil, and vanilla extract if using. Whisk with a fork until smooth and no lumps remain.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Microwave",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1585238341710-9c2d34c0e33e?w=800&q=80",
            text: "Microwave on high for 1 minute 30 seconds to 2 minutes, depending on your microwave power. Cake should rise and be set in the center.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=800&q=80",
            text: "Let cool for 1 minute. Enjoy straight from the mug or turn out onto a plate. Top with ice cream or whipped cream if desired.",
          },
        ],
      },
    ],
  },

  // Recipe 3: Coconut Jelly (with placeholders)
  {
    id: "coconut-jelly",
    name: "Coconut Jelly",
    category: "Dessert Menu",
    image: "/images/coconut-jelly.jpg",
    time: "20 mins + 2 hours chilling",
    servings: 4,
    rating: 4,
    isFavorite: false,
    ingredients: [
      "1 can (400ml) coconut milk",
      "1 cup water",
      "1/2 cup sugar",
      "2 tablespoons agar-agar powder or gelatin",
      "1/4 teaspoon pandan extract or vanilla extract",
      "Fresh fruits for topping (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Mix ingredients",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "In a pot, combine coconut milk, water, sugar, and agar-agar powder. Whisk until well combined.",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Heat and dissolve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Place pot over medium heat. Stir constantly until mixture comes to a boil and sugar and agar-agar are completely dissolved (about 5 minutes).",
            clickableTerms: [{ term: "boil", positions: [79, 83] }],
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add flavor and pour",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Remove from heat and stir in pandan or vanilla extract. Pour into a shallow dish or individual molds.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Chill and serve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Let cool to room temperature, then refrigerate for at least 2 hours until set. Cut into cubes and serve with fresh fruits if desired.",
          },
        ],
      },
    ],
  },

  // Recipe 4: Mango Yogurt Parfait (with placeholders)
  {
    id: "mango-yogurt-parfait",
    name: "Mango Yogurt Parfait",
    category: "Dessert Menu",
    image: "/images/mango-yogurt-parfait.jpg",
    time: "10 mins",
    servings: 2,
    rating: 5,
    isFavorite: false,
    ingredients: [
      "2 cups Greek yogurt or plain yogurt",
      "2 tablespoons honey",
      "1 ripe mango, diced",
      "1/2 cup granola",
      "2 tablespoons coconut flakes (optional)",
      "Fresh mint leaves for garnish (optional)",
    ],
    steps: [
      {
        title: "STEP 1",
        subtitle: "Prepare yogurt",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "In a bowl, mix yogurt with 1 tablespoon honey until well combined.",
          },
        ],
      },
      {
        title: "STEP 2",
        subtitle: "Layer ingredients",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "In serving glasses or jars, layer yogurt, diced mango, and granola. Repeat layers until glasses are filled.",
          },
        ],
      },
      {
        title: "STEP 3",
        subtitle: "Add toppings",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Top with remaining honey drizzle, coconut flakes, and fresh mint leaves if using.",
          },
        ],
      },
      {
        title: "STEP 4",
        subtitle: "Serve",
        instructions: [
          {
            image: "/placeholder.svg?height=400&width=600",
            text: "Serve immediately or refrigerate for up to 2 hours before serving.",
          },
        ],
      },
    ],
  },
]

export const ingredientSubstitutions: Record<string, Array<{ original: string; substitute: string; image: string }>> = {
  // Student Friendly Menu
  "nasi-goreng-biasa": [
    {
      original: "Day-old Rice",
      substitute: "Fresh rice (spread thin)",
      image: "https://images.unsplash.com/photo-1516684732162-798a0062be99?w=200&h=200&fit=crop",
    },
    {
      original: "Garlic",
      substitute: "Garlic powder",
      image: "https://images.unsplash.com/photo-1587281176307-0003fcf249a0?w=200&h=200&fit=crop",
    },
  ],
  "telur-kicap-berlado": [
    {
      original: "Sambal Paste",
      substitute: "Chili flakes in oil",
      image: "https://images.unsplash.com/photo-1583032015627-f581e5e113b7?w=200&h=200&fit=crop",
    },
    {
      original: "Soy Sauce",
      substitute: "Salt + sugar pinch",
      image: "https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?w=200&h=200&fit=crop",
    },
  ],
  "simple-fried-egg-soy-sauce-rice": [
    {
      original: "Soy Sauce",
      substitute: "Oyster sauce",
      image: "https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?w=200&h=200&fit=crop",
    },
    {
      original: "Green Onions",
      substitute: "Dried parsley",
      image: "https://images.unsplash.com/photo-1523049673857-eb18f19b6a78?w=200&h=200&fit=crop",
    },
  ],
  "curry-flavoured-maggie": [
    {
      original: "Cabbage/Carrots",
      substitute: "Frozen mixed veg",
      image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?w=200&h=200&fit=crop",
    },
    {
      original: "Sesame Oil",
      substitute: "Butter",
      image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&h=200&fit=crop",
    },
  ],

  // Quick and Easy Menu
  "quick-chicken-stir-fry": [
    {
      original: "Chicken",
      substitute: "Tofu/Beef",
      image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=200&h=200&fit=crop",
    },
    {
      original: "Ginger",
      substitute: "Ground ginger",
      image: "https://images.unsplash.com/photo-1576668638106-e59a1f40c6aa?w=200&h=200&fit=crop",
    },
  ],
  "garlic-butter-fried-rice": [
    {
      original: "Butter",
      substitute: "Margarine",
      image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&h=200&fit=crop",
    },
    {
      original: "Mixed Vegetables",
      substitute: "Canned peas",
      image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?w=200&h=200&fit=crop",
    },
  ],
  "thai-basil-chicken": [
    {
      original: "Thai Basil",
      substitute: "Regular basil/Mint",
      image: "https://images.unsplash.com/photo-1618375569909-3c8616cf7733?w=200&h=200&fit=crop",
    },
    {
      original: "Fish Sauce",
      substitute: "Extra soy sauce",
      image: "https://images.unsplash.com/photo-1603055431968-0f0e26e5c0ab?w=200&h=200&fit=crop",
    },
  ],
  "easy-stir-fry-noodles": [
    {
      original: "Yellow Noodles",
      substitute: "Spaghetti",
      image: "https://images.unsplash.com/photo-1612874742237-652f88816120?w=200&h=200&fit=crop",
    },
    {
      original: "Oyster Sauce",
      substitute: "Hoisin sauce",
      image: "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=200&h=200&fit=crop",
    },
  ],

  // Asian Menu
  "teriyaki-chicken-bowl": [
    {
      original: "Honey",
      substitute: "Brown sugar",
      image: "https://images.unsplash.com/photo-1587049352846-4a222e784262?w=200&h=200&fit=crop",
    },
    {
      original: "Oyster Sauce",
      substitute: "Worcestershire sauce",
      image: "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=200&h=200&fit=crop",
    },
  ],
  "kimchi-fried-rice": [
    {
      original: "Kimchi",
      substitute: "Pickled cabbage + sriracha",
      image: "https://images.unsplash.com/photo-1633030841495-ca46c0a0a2e6?w=200&h=200&fit=crop",
    },
    {
      original: "Sesame Oil",
      substitute: "Peanut oil",
      image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&h=200&fit=crop",
    },
  ],
  "garlic-sesame-tofu": [
    {
      original: "Firm Tofu",
      substitute: "Tempeh",
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&h=200&fit=crop",
    },
    {
      original: "Sesame Seeds",
      substitute: "Crushed peanuts",
      image: "https://images.unsplash.com/photo-1621939514649-280e2ee25960?w=200&h=200&fit=crop",
    },
  ],
  "sambal-sardine-stir-fry": [
    {
      original: "Sardines",
      substitute: "Canned tuna",
      image: "https://images.unsplash.com/photo-1580217593608-61931cefc821?w=200&h=200&fit=crop",
    },
    {
      original: "Lime",
      substitute: "Lemon/Vinegar",
      image: "https://images.unsplash.com/photo-1590502593747-4a996133562?w=200&h=200&fit=crop",
    },
  ],

  // Western Menu
  "creamy-garlic-chicken": [
    {
      original: "Cream/Milk",
      substitute: "Evaporated milk",
      image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=200&h=200&fit=crop",
    },
    {
      original: "Parsley",
      substitute: "Dried oregano",
      image: "https://images.unsplash.com/photo-1595859908844-5e198e0f6880?w=200&h=200&fit=crop",
    },
  ],
  "classic-mashed-potato-gravy": [
    {
      original: "Butter",
      substitute: "Olive oil",
      image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&h=200&fit=crop",
    },
    {
      original: "Chicken Stock",
      substitute: "Vegetable stock",
      image: "https://images.unsplash.com/photo-1547424450-6c9892e27e23?w=200&h=200&fit=crop",
    },
  ],
  "simple-butter-herb-pasta": [
    {
      original: "Mixed Herbs",
      substitute: "Dried basil",
      image: "https://images.unsplash.com/photo-1543363136-3fdb62e1be3?w=200&h=200&fit=crop",
    },
    {
      original: "Grated Cheese",
      substitute: "Nutritional yeast",
      image: "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=200&h=200&fit=crop",
    },
  ],
  "cheesy-omelette": [
    {
      original: "Milk",
      substitute: "Water",
      image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=200&h=200&fit=crop",
    },
    {
      original: "Mushrooms",
      substitute: "Bell peppers/Spinach",
      image: "https://images.unsplash.com/photo-1621668951823-7415e344cdfe?w=200&h=200&fit=crop",
    },
  ],

  // Vegetarian Menu
  "stir-fried-tofu-vegetables": [
    {
      original: "Tofu",
      substitute: "Seitan",
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&h=200&fit=crop",
    },
    {
      original: "Broccoli",
      substitute: "Cauliflower",
      image: "https://images.unsplash.com/photo-1459411621453-e335323308f3?w=200&h=200&fit=crop",
    },
  ],
  "sweet-soy-glazed-tempeh": [
    {
      original: "Sweet Soy Sauce",
      substitute: "Soy sauce + honey",
      image: "https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?w=200&h=200&fit=crop",
    },
    {
      original: "Garlic",
      substitute: "Garlic paste",
      image: "https://images.unsplash.com/photo-1587281176307-0003fcf249a0?w=200&h=200&fit=crop",
    },
  ],
  "vegetable-curry": [
    {
      original: "Coconut Milk",
      substitute: "Heavy cream",
      image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=200&h=200&fit=crop",
    },
    {
      original: "Potatoes",
      substitute: "Sweet potatoes",
      image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=200&h=200&fit=crop",
    },
  ],
  "mushroom-garlic-noodles": [
    {
      original: "Butter",
      substitute: "Coconut oil",
      image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&h=200&fit=crop",
    },
    {
      original: "Soy Sauce",
      substitute: "Tamari",
      image: "https://images.unsplash.com/photo-1618897996318-5a901fa6ca71?w=200&h=200&fit=crop",
    },
  ],

  // Dessert Menu
  "honey-banana-pancake": [
    {
      original: "Honey",
      substitute: "Maple syrup",
      image: "https://images.unsplash.com/photo-1587049352846-4a222e784262?w=200&h=200&fit=crop",
    },
    {
      original: "Banana",
      substitute: "Berries",
      image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=200&h=200&fit=crop",
    },
  ],
  "milo-mug-cake": [
    {
      original: "Milo Powder",
      substitute: "Cocoa powder + sugar",
      image: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=200&h=200&fit=crop",
    },
    {
      original: "Egg",
      substitute: "Banana mash",
      image: "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=200&h=200&fit=crop",
    },
  ],
  "coconut-jelly": [
    {
      original: "Coconut Water",
      substitute: "Coconut milk + water",
      image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=200&h=200&fit=crop",
    },
    {
      original: "Agar-Agar",
      substitute: "Gelatin",
      image: "https://images.unsplash.com/photo-1613478881426-c844e4c01859?w=200&h=200&fit=crop",
    },
  ],
  "mango-yogurt-parfait": [
    {
      original: "Mango",
      substitute: "Peaches",
      image: "https://images.unsplash.com/photo-1553279768-8654299a0078?w=200&h=200&fit=crop",
    },
    {
      original: "Greek Yogurt",
      substitute: "Regular yogurt",
      image: "https://images.unsplash.com/photo-1488477181946-64280a0291777?w=200&h=200&fit=crop",
    },
  ],
}

export function getRecipesByCategory(category: string): Recipe[] {
  return recipes.filter((recipe) => recipe.category === category)
}

export function getAllCategories(): string[] {
  const categories = recipes.map((recipe) => recipe.category)
  return Array.from(new Set(categories))
}

export function getRecipeById(id: string): Recipe | undefined {
  return recipes.find((recipe) => recipe.id === id)
}

export const cookingTerms: Record<string, { term: string; definition: string }> = {
  sauté: {
    term: "Sauté",
    definition: "To cook food quickly in a small amount of oil or fat over relatively high heat, stirring frequently.",
  },
  "stir-fry": {
    term: "Stir-fry",
    definition: "To cook small pieces of food quickly over high heat while stirring constantly, typically in a wok.",
  },
  boil: {
    term: "Boil",
    definition: "To heat liquid until bubbles break the surface (212°F/100°C for water at sea level).",
  },
  simmer: {
    term: "Simmer",
    definition:
      "To cook liquid gently just below the boiling point, with small bubbles occasionally rising to the surface.",
  },
  "pan-fry": {
    term: "Pan-fry",
    definition: "To cook food in a moderate amount of fat in a shallow pan over moderate heat.",
  },
  fry: {
    term: "Fry",
    definition: "To cook food in hot oil or fat, typically until crispy or golden brown.",
  },
  "al dente": {
    term: "Al dente",
    definition: "Italian term meaning 'to the tooth' - pasta or rice cooked so it's still firm when bitten.",
  },
  fold: {
    term: "Fold",
    definition:
      "To gently combine ingredients using a spatula in a circular motion from the bottom up, maintaining airiness.",
  },
  poach: {
    term: "Poach",
    definition: "To cook food gently in liquid that is barely simmering, just below boiling point.",
  },
}
