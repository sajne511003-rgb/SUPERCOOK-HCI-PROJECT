export interface CookingTermDefinition {
  term: string
  definition: string
}

// Define the cooking terms with their definitions
export const COOKING_TERMS_DEFINITIONS: Record<string, CookingTermDefinition> = {
  "pan-fry": {
    term: "Pan-fry",
    definition: "To fry food in a small amount of oil in a shallow pan.",
  },
  garnish: {
    term: "Garnish",
    definition: "To decorate or embellish a dish with small amounts of food for visual appeal.",
  },
  season: {
    term: "Season",
    definition: "To add salt, pepper, herbs, or spices to enhance the flavor of food.",
  },
  "stir-fry": {
    term: "Stir-fry",
    definition: "To fry meat or vegetables rapidly over high heat while stirring constantly.",
  },
  "stir fry": {
    term: "Stir fry",
    definition: "To fry meat or vegetables rapidly over high heat while stirring constantly.",
  },
  sauté: {
    term: "Sauté",
    definition: "To fry food quickly in a small amount of hot oil while stirring.",
  },
  marinate: {
    term: "Marinate",
    definition: "To soak food in a seasoned liquid before cooking to add flavor.",
  },
  simmer: {
    term: "Simmer",
    definition: "To cook in liquid just below the boiling point; look for small bubbles.",
  },
  mince: {
    term: "Mince",
    definition: "To chop food into very small pieces.",
  },
  sear: {
    term: "Sear",
    definition: "To cook the surface of food at high temperature until a brown crust forms.",
  },
  "al dente": {
    term: "Al Dente",
    definition: "Cooked so as to be still firm when bitten (typically used for pasta).",
  },
  boil: {
    term: "Boil",
    definition: "To heat liquid until bubbles rise rapidly to the surface and break.",
  },
  caramelize: {
    term: "Caramelize",
    definition: "To cook sugar or food containing sugar until it turns brown and develops a rich, sweet flavor.",
  },
}

// Get all target cooking terms as a list
export const TARGET_TERMS = [
  "pan-fry",
  "garnish",
  "season",
  "stir-fry",
  "stir fry",
  "sauté",
  "marinate",
  "simmer",
  "mince",
  "sear",
  "al dente",
  "boil",
  "caramelize",
]

export interface TermMatch {
  term: string
  start: number
  end: number
  matchedText: string
}

/**
 * Finds all occurrences of cooking terms in a text string (case-insensitive)
 * Returns array of matches with their positions
 */
export function findCookingTerms(text: string): TermMatch[] {
  const matches: TermMatch[] = []
  const lowerText = text.toLowerCase()

  TARGET_TERMS.forEach((term) => {
    const lowerTerm = term.toLowerCase()
    let startIndex = 0

    while (true) {
      const index = lowerText.indexOf(lowerTerm, startIndex)
      if (index === -1) break

      matches.push({
        term: term,
        start: index,
        end: index + term.length,
        matchedText: text.slice(index, index + term.length),
      })

      startIndex = index + term.length
    }
  })

  // Sort by position to render in order
  return matches.sort((a, b) => a.start - b.start)
}

/**
 * Get definition for a cooking term (case-insensitive lookup)
 */
export function getCookingTermDefinition(term: string): CookingTermDefinition | null {
  const lowerTerm = term.toLowerCase()
  return COOKING_TERMS_DEFINITIONS[lowerTerm] || null
}
