"use client"

import { ChevronLeft, Home, Heart, User, Clock, Users, Star, ChefHat } from "lucide-react"
import Image from "next/image"
import { useFavorites } from "@/lib/favorites-context"
import { recipes } from "@/lib/recipe-data"

interface FavoritesScreenProps {
  onBack: () => void
  onSelectRecipe: (recipeId: string) => void
  onNavigateHome: () => void
  onNavigateProfile: () => void
}

export function FavoritesScreen({ onBack, onSelectRecipe, onNavigateHome, onNavigateProfile }: FavoritesScreenProps) {
  const { favorites, toggleFavorite, isFavorite } = useFavorites()

  const favoriteRecipes = recipes.filter((recipe) => isFavorite(recipe.id))

  const getImageSrc = (imagePath: string | undefined) => {
    return imagePath || "https://v0.dev/placeholder.svg?height=400&width=600"
  }

  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg">
      <div className="bg-[#D98E54] border-b border-brown/10 p-4">
        <div className="flex items-center justify-center gap-3 mb-3 relative">
          <button
            onClick={onBack}
            className="p-1 absolute left-0 touch-manipulation active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2 touch-manipulation active:scale-95 transition-transform"
          >
            <h1 className="text-lg font-serif font-bold text-white">SUPERCOOK</h1>
            <ChefHat className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {favoriteRecipes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-6">
            <Heart className="w-16 h-16 text-brown/30 mb-4" />
            <p className="text-brown/60 text-lg mb-2">Your favourites list is empty.</p>
            <p className="text-brown/50 text-sm">Start hearting recipes to see them here!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {favoriteRecipes.map((recipe) => (
              <button
                key={recipe.id}
                onClick={() => onSelectRecipe(recipe.id)}
                className="bg-white border border-brown/10 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow active:scale-95"
              >
                <div className="aspect-square relative">
                  <Image
                    src={getImageSrc(recipe.image) || "/placeholder.svg"}
                    alt={recipe.name}
                    fill
                    className="object-cover"
                  />
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleFavorite(recipe.id)
                    }}
                    className="absolute top-2 right-2 p-1.5 bg-white/90 rounded-full hover:bg-white transition-colors"
                  >
                    <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                  </button>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-brown text-sm mb-1.5">{recipe.name}</h3>
                  <div className="flex items-center gap-0.5 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-brown/60">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{recipe.time}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      <span>{recipe.servings}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <nav className="bg-[#D98E54] border-t border-brown/10 px-8 py-3 flex justify-around">
        <button
          onClick={onNavigateHome}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white active:scale-95 transition-transform">
          <Heart className="w-6 h-6" />
          <span className="text-xs font-medium">Favourites</span>
        </button>
        <button
          onClick={onNavigateProfile}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
