"use client"

import type React from "react"
import { useState, useMemo } from "react"
import { ChevronLeft, Home, Heart, User, Clock, Users, Star, Search, ChefHat } from "lucide-react"
import Image from "next/image"
import { getRecipesByCategory } from "@/lib/recipe-data"
import { useFavorites } from "@/lib/favorites-context"

interface RecipeListProps {
  category: string
  onBack: () => void
  onSelectRecipe: (recipeId: string) => void
  onShowFavorites: () => void
  onShowProfile: () => void
  onNavigateHome: () => void
}

export function RecipeList({
  category,
  onBack,
  onSelectRecipe,
  onShowFavorites,
  onShowProfile,
  onNavigateHome,
}: RecipeListProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const categoryRecipes = getRecipesByCategory(category)
  const { toggleFavorite, isFavorite } = useFavorites()

  const filteredRecipes = useMemo(() => {
    return categoryRecipes.filter((recipe) => {
      const matchesSearch =
        !searchQuery ||
        recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()))

      return matchesSearch
    })
  }, [categoryRecipes, searchQuery])

  const handleToggleFavorite = (recipeId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    toggleFavorite(recipeId)
  }

  const getImageSrc = (imagePath: string | undefined) => {
    return imagePath || "https://v0.dev/placeholder.svg?height=400&width=600"
  }

  const showNoResults = filteredRecipes.length === 0

  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg">
      <div className="bg-[#D98E54] border-b border-brown/10 p-4">
        <div className="flex items-center justify-center gap-3 mb-3 relative">
          <button
            onClick={onBack}
            className="p-1 absolute left-0 touch-manipulation active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2 touch-manipulation active:scale-95 transition-transform"
          >
            <h1 className="text-lg font-serif font-bold text-white">SUPERCOOK</h1>
            <ChefHat className="w-5 h-5 text-white" />
          </button>
        </div>
        <div className="relative">
          <input
            type="text"
            placeholder="Search for recipes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-full text-sm bg-white focus:outline-none focus:ring-2 focus:ring-supercook-button/30"
          />
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>
      </div>

      {/* Recipe Grid */}
      <div className="flex-1 p-4">
        {showNoResults ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <p className="text-brown/60 text-lg mb-2">No recipes found.</p>
            <p className="text-brown/40 text-sm">Try a different keyword!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredRecipes.map((recipe) => (
              <button
                key={recipe.id}
                onClick={() => onSelectRecipe(recipe.id)}
                className="bg-white border border-brown/10 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow active:scale-95"
              >
                <div className="aspect-square relative">
                  <Image
                    src={getImageSrc(recipe.image) || "/placeholder.svg"}
                    alt={recipe.name}
                    fill
                    className="object-cover"
                  />
                  <button
                    onClick={(e) => handleToggleFavorite(recipe.id, e)}
                    className="absolute top-2 right-2 p-1.5 bg-white/90 rounded-full hover:bg-white transition-colors"
                  >
                    <Heart
                      className={`w-4 h-4 ${isFavorite(recipe.id) ? "fill-red-500 text-red-500" : "text-brown/60"}`}
                    />
                  </button>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-brown text-sm mb-1.5">{recipe.name}</h3>
                  <div className="flex items-center gap-0.5 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-brown/60">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{recipe.time}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      <span>{recipe.servings}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <nav className="bg-[#D98E54] border-t border-brown/10 px-8 py-3 flex justify-around">
        <button
          onClick={onBack}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </button>
        <button
          onClick={onShowFavorites}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button
          onClick={onShowProfile}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
