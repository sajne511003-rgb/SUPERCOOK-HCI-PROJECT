"use client"

import type React from "react"

import { useState } from "react"
import { ChefHat } from "lucide-react"

interface LoginScreenProps {
  onLogin: (username: string) => void
  onNavigateToSignup: () => void
}

export function LoginScreen({ onLogin, onNavigateToSignup }: LoginScreenProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (username.trim()) {
      onLogin(username.trim())
    }
  }

  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg">
      {/* Header */}
      <div className="bg-supercook-nav border-b border-brown/10 p-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <ChefHat className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">SUPERCOOK</h1>
      </div>

      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
          <div>
            <input
              type="text"
              placeholder="Username or Email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl text-base bg-white focus:outline-none focus:ring-2 focus:ring-supercook-nav/30 focus:border-supercook-nav/50"
              required
            />
          </div>
          <div>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl text-base bg-white focus:outline-none focus:ring-2 focus:ring-supercook-nav/30 focus:border-supercook-nav/50"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-supercook-nav text-white font-bold text-lg py-3 rounded-full hover:bg-supercook-nav/90 active:scale-95 transition-all shadow-md"
          >
            LOGIN
          </button>
          <div className="text-center pt-4">
            <button
              type="button"
              onClick={onNavigateToSignup}
              className="text-brown/70 text-sm hover:text-brown active:scale-95 transition-all"
            >
              Don't have an account? <span className="text-supercook-nav font-semibold underline">Sign up here</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
