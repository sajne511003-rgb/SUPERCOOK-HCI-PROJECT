"use client"

import { X } from "lucide-react"
import Image from "next/image"
import { ingredientSubstitutions } from "@/lib/recipe-data"

interface IngredientSubstitutionProps {
  onClose: () => void
  recipeId?: string
}

export function IngredientSubstitution({ onClose, recipeId }: IngredientSubstitutionProps) {
  const substitutions = recipeId && ingredientSubstitutions[recipeId] ? ingredientSubstitutions[recipeId] : []

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-[#FDF5E6] rounded-3xl max-w-md w-full max-h-[80vh] overflow-y-auto flex flex-col">
        <div className="sticky top-0 bg-[#FDF5E6] border-b border-brown/10 p-4 flex items-center justify-between z-10">
          <h2 className="text-xl font-black text-brown">INGREDIENT SUBSTITUTE</h2>
          <button onClick={onClose} className="p-1 touch-manipulation active:scale-95 transition-transform">
            <X className="w-6 h-6 text-brown" />
          </button>
        </div>

        <div className="p-4 flex-1 overflow-y-auto pb-24">
          <p className="text-brown/70 text-sm mb-4 font-medium">If you don't have one, use the other!</p>

          {substitutions.length > 0 ? (
            <div className="space-y-3">
              {substitutions.map((sub, index) => (
                <div key={index} className="bg-white border border-brown/10 rounded-2xl p-4 flex items-center gap-4">
                  <div className="relative w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 border border-brown/10">
                    <Image src={sub.image || "/placeholder.svg"} alt={sub.original} fill className="object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-brown mb-1">{sub.original}</div>
                    <div className="text-sm text-brown/60">→ {sub.substitute}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-brown/60">
              <p>No substitutions available for this recipe.</p>
            </div>
          )}
        </div>

        <div className="sticky bottom-0 bg-[#FDF5E6] border-t border-brown/10 p-4 z-10">
          <button
            onClick={onClose}
            className="w-full bg-[#D78D43] hover:bg-[#C97D33] text-white font-bold py-4 px-6 rounded-xl transition-colors touch-manipulation active:scale-95 shadow-lg"
          >
            Confirm & Return
          </button>
        </div>
      </div>
    </div>
  )
}
