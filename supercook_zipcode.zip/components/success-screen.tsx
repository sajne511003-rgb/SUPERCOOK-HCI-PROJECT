"use client"

import { Home, Heart, User, Star } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

interface SuccessScreenProps {
  recipeId?: string
  recipeName?: string
  recipeImage?: string
  onDone: () => void
}

export function SuccessScreen({ recipeId, recipeName, recipeImage, onDone }: SuccessScreenProps) {
  const [rating, setRating] = useState(0)

  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg">
      {/* Header */}
      <div className="bg-supercook-nav border-b border-brown/10 p-4">
        <h1 className="text-center text-3xl font-serif font-bold text-white">You Did It!</h1>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 pb-24">
        <div className="relative w-64 h-64 rounded-3xl overflow-hidden border-4 border-supercook-nav mb-6">
          <Image
            src={recipeImage || "/placeholder.svg?height=300&width=300"}
            alt="Finished dish"
            fill
            className="object-cover"
          />
        </div>

        <h2 className="text-2xl font-serif font-bold text-brown mb-2 text-center">
          {recipeName?.toUpperCase() || "RECIPE COMPLETE"}
        </h2>

        <div className="flex gap-2 my-6">
          {[1, 2, 3, 4, 5].map((star) => (
            <button key={star} onClick={() => setRating(star)} className="transition-transform hover:scale-110">
              <Star
                className={`w-10 h-10 ${
                  star <= rating ? "fill-yellow-400 text-yellow-400" : "fill-none text-brown/20"
                }`}
              />
            </button>
          ))}
        </div>

        <div className="w-full space-y-3">
          <button className="w-full bg-supercook-secondary text-white font-medium py-4 rounded-full hover:bg-supercook-secondary/90 transition-colors">
            Rate This Recipe
          </button>
          <button
            onClick={onDone}
            className="w-full bg-supercook-secondary text-white font-medium py-4 rounded-full hover:bg-supercook-secondary/90 transition-colors"
          >
            Try It Again
          </button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-supercook-nav border-t border-brown/10 px-8 py-3 flex justify-around max-w-md mx-auto">
        <button className="flex flex-col items-center gap-1 text-white">
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Home</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60">
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
