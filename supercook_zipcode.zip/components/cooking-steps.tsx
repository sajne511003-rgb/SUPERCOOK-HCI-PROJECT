"use client"

import { ChevronLeft, Home, Heart, User, ArrowRightLeft, ChefHat } from "lucide-react"
import Image from "next/image"
import { getRecipeById } from "@/lib/recipe-data"
import { findCookingTerms } from "@/lib/cooking-terms-utils"
import { useState } from "react"
import { CookingTermTooltip } from "@/components/cooking-term-tooltip"

interface CookingStepsProps {
  recipeId: string
  step: number
  onNext: () => void
  onPrev: () => void
  onShowDefinition: (term: string) => void
  onShowSubstitution: () => void
  onComplete: () => void
  onNavigateHome: () => void
}

export function CookingSteps({
  recipeId,
  step,
  onNext,
  onPrev,
  onShowDefinition,
  onShowSubstitution,
  onComplete,
  onNavigateHome,
}: CookingStepsProps) {
  const [tooltipTerm, setTooltipTerm] = useState<string | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null)

  const recipe = getRecipeById(recipeId)

  if (!recipe) {
    return <div>Recipe not found</div>
  }

  const currentStepData = recipe.steps[Math.min(step, recipe.steps.length - 1)]
  const isLastStep = step >= recipe.steps.length - 1

  const getImageSrc = (imagePath: string | undefined) => {
    return imagePath || "https://v0.dev/placeholder.svg?height=400&width=600"
  }

  const renderInstructionText = (instruction: any) => {
    const text = instruction.text
    const matches = findCookingTerms(text)

    if (matches.length === 0) {
      return text
    }

    const parts = []
    let lastIndex = 0

    matches.forEach((match, idx) => {
      if (match.start > lastIndex) {
        parts.push(text.slice(lastIndex, match.start))
      }

      parts.push(
        <span
          key={idx}
          className="text-[#FF0000] font-bold underline cursor-pointer"
          onClick={(e) => {
            const rect = (e.target as HTMLElement).getBoundingClientRect()
            setTooltipPosition({ x: rect.left + rect.width / 2, y: rect.top })
            setTooltipTerm(match.term)
          }}
          onMouseEnter={(e) => {
            const rect = (e.target as HTMLElement).getBoundingClientRect()
            setTooltipPosition({ x: rect.left + rect.width / 2, y: rect.top })
            setTooltipTerm(match.term)
          }}
          onMouseLeave={() => {
            setTooltipTerm(null)
            setTooltipPosition(null)
          }}
        >
          {match.matchedText}
        </span>,
      )

      lastIndex = match.end
    })

    if (lastIndex < text.length) {
      parts.push(text.slice(lastIndex))
    }

    return <span>{parts}</span>
  }

  let stepNumberOffset = 0
  for (let i = 0; i < step; i++) {
    stepNumberOffset += recipe.steps[i].instructions.length
  }

  return (
    <div className="max-w-md mx-auto h-screen flex flex-col bg-supercook-bg">
      <div className="fixed top-0 left-0 right-0 bg-[#D98E54] border-b border-brown/10 p-4 max-w-md mx-auto z-20">
        <div className="flex items-center justify-center relative">
          <button
            onClick={onPrev}
            className="p-1 absolute left-0 touch-manipulation active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2 touch-manipulation active:scale-95 transition-transform"
          >
            <h1 className="text-lg font-serif font-bold text-white">SUPERCOOK</h1>
            <ChefHat className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-16 pb-32">
        <div className="p-4 space-y-6">
          {currentStepData.instructions.map((instruction, index) => (
            <div key={index} className="space-y-3">
              <p className="text-brown leading-relaxed">
                <span className="font-black text-2xl mr-2" style={{ fontFamily: "Arial Black, Arial, sans-serif" }}>
                  {stepNumberOffset + index + 1}.
                </span>
                <span className="font-bold text-base">{renderInstructionText(instruction)}</span>
              </p>

              <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-brown/10">
                <Image
                  src={getImageSrc(instruction.image) || "/placeholder.svg"}
                  alt={`Step ${stepNumberOffset + index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="fixed bottom-16 left-0 right-0 p-4 bg-supercook-bg max-w-md mx-auto z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={onShowSubstitution}
            className="flex-1 bg-[#F5E6D3] border border-brown/20 text-black font-bold py-4 px-6 rounded-xl hover:bg-[#F5E6D3]/80 transition-colors flex items-center justify-center gap-2 touch-manipulation active:scale-95"
          >
            <ArrowRightLeft className="w-6 h-6" />
            <span className="text-sm">Ingredient Substitution</span>
          </button>

          <button
            onClick={isLastStep ? onComplete : onNext}
            className={`px-8 py-4 font-bold text-black rounded-xl transition-colors touch-manipulation active:scale-95 ${
              isLastStep ? "bg-[#90EE90] hover:bg-[#90EE90]/90" : "bg-[#E6A76A] hover:bg-[#E6A76A]/90"
            }`}
          >
            {isLastStep ? "DONE COOKING" : "NEXT"}
          </button>
        </div>
      </div>

      {tooltipTerm && tooltipPosition && (
        <CookingTermTooltip
          term={tooltipTerm}
          position={tooltipPosition}
          onClose={() => {
            setTooltipTerm(null)
            setTooltipPosition(null)
          }}
        />
      )}

      <nav className="fixed bottom-0 left-0 right-0 bg-[#D98E54] border-t border-brown/10 px-8 py-3 flex justify-around max-w-md mx-auto z-20">
        <button className="flex flex-col items-center gap-1 text-white touch-manipulation active:scale-95 transition-transform">
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Home</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform">
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
