"use client"

import { useState, useMemo } from "react"
import { Home, Heart, BookOpen, Clock, Coffee, Cake, UtensilsCrossed, Leaf, Search, User, ChefHat } from "lucide-react"
import { recipes } from "@/lib/recipe-data"

interface MainMenuProps {
  onNavigate: (category: string) => void
  onShowFavorites: () => void
  onShowProfile: () => void
}

export function MainMenu({ onNavigate, onShowFavorites, onShowProfile }: MainMenuProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState("All Recipes")

  const categories = [
    { name: "Student Friendly\nRecipes", icon: BookOpen, category: "Student Friendly" },
    { name: "Quick and\nEasy Meals", icon: Clock, category: "Quick and Easy" },
    { name: "Western\nMenu", icon: UtensilsCrossed, category: "Western Menu" },
    { name: "Asian\nMenu", icon: Coffee, category: "Asian Menu" },
    { name: "Vegetarian", icon: Leaf, category: "Vegetarian Menu" },
    { name: "Dessert", icon: Cake, category: "Dessert Menu" },
  ]

  const filterChips = [
    { label: "All Recipes", category: null },
    { label: "Student", category: "Student Friendly" },
    { label: "Easy", category: "Quick and Easy" },
    { label: "Western", category: "Western Menu" },
    { label: "Asian", category: "Asian Menu" },
    { label: "Vegetarian", category: "Vegetarian Menu" },
    { label: "Dessert", category: "Dessert Menu" },
  ]

  const filteredCategories = useMemo(() => {
    if (!searchQuery && activeFilter === "All Recipes") {
      return categories
    }

    // Get recipes that match search and filter
    const matchingRecipes = recipes.filter((recipe) => {
      const matchesSearch =
        !searchQuery ||
        recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.category.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesFilter =
        activeFilter === "All Recipes" ||
        recipe.category === filterChips.find((f) => f.label === activeFilter)?.category

      return matchesSearch && matchesFilter
    })

    // Get unique categories from matching recipes
    const matchingCategories = new Set(matchingRecipes.map((r) => r.category))

    // Filter category buttons to show only those with matching recipes
    return categories.filter((cat) => matchingCategories.has(cat.category))
  }, [searchQuery, activeFilter])

  const showNoResults = searchQuery && filteredCategories.length === 0

  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg touch-manipulation">
      <div className="bg-[#D98E54] border-b border-brown/10 p-4 safe-top">
        <div className="flex items-center justify-center gap-2 mb-3">
          <h1 className="text-xl font-serif font-bold text-white">SUPERCOOK</h1>
          <ChefHat className="w-6 h-6 text-white" />
        </div>
        <div className="relative">
          <input
            type="text"
            placeholder="Search for recipes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 pr-10 border-2 border-gray-400 rounded-full text-sm bg-white/95 text-gray-800 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-400/40 focus:border-gray-500 touch-manipulation"
          />
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
        </div>
      </div>

      <div className="px-4 py-3 flex gap-2 overflow-x-auto scrollbar-hide">
        {filterChips.map((chip) => (
          <button
            key={chip.label}
            onClick={() => setActiveFilter(chip.label)}
            className={`px-4 py-1.5 rounded-full text-sm whitespace-nowrap font-medium touch-manipulation active:scale-95 transition-all ${
              activeFilter === chip.label
                ? "bg-supercook-secondary text-white shadow-md border-2 border-supercook-secondary"
                : "bg-[#FDF5E6] border-2 border-brown/30 text-brown shadow-sm"
            }`}
          >
            {chip.label}
          </button>
        ))}
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {showNoResults ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <p className="text-brown/60 text-lg mb-2">No recipes found.</p>
            <p className="text-brown/40 text-sm">Try a different keyword!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredCategories.map((category, index) => {
              const Icon = category.icon
              return (
                <button
                  key={index}
                  onClick={() => onNavigate(category.category)}
                  className="bg-white border border-brown/10 rounded-2xl p-6 flex flex-col items-center justify-center gap-3 hover:shadow-lg transition-all active:scale-95 touch-manipulation min-h-[140px]"
                >
                  <Icon className="w-10 h-10 text-brown" />
                  <span className="text-sm text-brown font-medium text-center whitespace-pre-line leading-snug">
                    {category.name}
                  </span>
                </button>
              )
            })}
          </div>
        )}
      </div>

      <nav className="bg-supercook-nav border-t border-brown/10 px-8 py-3 flex justify-around safe-bottom">
        <button className="flex flex-col items-center gap-1 text-white touch-manipulation active:scale-95 transition-transform">
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Home</span>
        </button>
        <button
          onClick={onShowFavorites}
          className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform"
        >
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button
          onClick={onShowProfile}
          className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform"
        >
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
