"use client"

import { Home, Heart, User, LogOut, Settings, BookOpen } from "lucide-react"

interface ProfileScreenProps {
  username: string
  onNavigateHome: () => void
  onNavigateFavorites: () => void
  onMyRecipes: () => void
  onLogout: () => void
}

export function ProfileScreen({
  username,
  onNavigateHome,
  onNavigateFavorites,
  onMyRecipes,
  onLogout,
}: ProfileScreenProps) {
  return (
    <div className="max-w-md mx-auto min-h-screen flex flex-col bg-supercook-bg">
      {/* Header */}
      <div className="bg-supercook-nav border-b border-brown/10 p-4">
        <h1 className="text-lg font-serif font-bold text-brown text-center">My Profile</h1>
      </div>

      {/* Profile Content */}
      <div className="flex-1 p-6">
        {/* Avatar & User Info */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-24 h-24 rounded-full bg-supercook-secondary/30 border-4 border-white shadow-lg flex items-center justify-center mb-4">
            <User className="w-12 h-12 text-supercook-secondary" />
          </div>
          <h2 className="text-2xl font-black text-brown mb-1">{username}</h2>
          <p className="text-brown/60 font-semibold">Cooking Level: Beginner</p>
        </div>

        {/* Menu Options */}
        <div className="space-y-3">
          <button
            onClick={onMyRecipes}
            className="w-full bg-supercook-secondary text-white font-bold text-base py-4 rounded-2xl hover:bg-supercook-secondary/90 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2"
          >
            <BookOpen className="w-5 h-5" />
            My Recipes
          </button>
          <button className="w-full bg-supercook-secondary text-white font-bold text-base py-4 rounded-2xl hover:bg-supercook-secondary/90 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2">
            <Settings className="w-5 h-5" />
            Settings
          </button>
          <button
            onClick={onLogout}
            className="w-full bg-supercook-secondary text-white font-bold text-base py-4 rounded-2xl hover:bg-supercook-secondary/90 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-supercook-nav border-t border-brown/10 px-8 py-3 flex justify-around">
        <button
          onClick={onNavigateHome}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <Home className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </button>
        <button
          onClick={onNavigateFavorites}
          className="flex flex-col items-center gap-1 text-white/60 active:scale-95 transition-transform"
        >
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white active:scale-95 transition-transform">
          <User className="w-6 h-6" />
          <span className="text-xs font-medium">Profile</span>
        </button>
      </nav>
    </div>
  )
}
