"use client"

import { getCookingTermDefinition } from "@/lib/cooking-terms-utils"
import { useEffect, useRef } from "react"

interface CookingTermTooltipProps {
  term: string
  position: { x: number; y: number }
  onClose: () => void
}

export function CookingTermTooltip({ term, position, onClose }: CookingTermTooltipProps) {
  const tooltipRef = useRef<HTMLDivElement>(null)
  const termData = getCookingTermDefinition(term)

  useEffect(() => {
    // Close tooltip when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (tooltipRef.current && !tooltipRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [onClose])

  if (!termData) {
    return null
  }

  return (
    <div
      ref={tooltipRef}
      className="fixed z-50 bg-white border-2 border-red-600 rounded-xl shadow-xl p-4 max-w-xs"
      style={{
        left: `${position.x}px`,
        top: `${position.y - 10}px`,
        transform: "translate(-50%, -100%)",
      }}
    >
      <div className="space-y-2">
        <h3 className="font-bold text-brown text-base border-b border-brown/20 pb-2">{termData.term}</h3>
        <p className="text-brown/80 text-sm leading-relaxed">{termData.definition}</p>
      </div>
    </div>
  )
}
