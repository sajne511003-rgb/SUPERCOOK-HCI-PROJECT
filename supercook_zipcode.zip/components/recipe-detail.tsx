"use client"

import { ChevronLeft, Home, Heart, User, Clock, Users, Star, ChefHat } from "lucide-react"
import Image from "next/image"
import { getRecipeById } from "@/lib/recipe-data"
import { useFavorites } from "@/lib/favorites-context"

interface RecipeDetailProps {
  recipeId: string
  onBack: () => void
  onStartCooking: () => void
  onNavigateHome: () => void
}

export function RecipeDetail({ recipeId, onBack, onStartCooking, onNavigateHome }: RecipeDetailProps) {
  const recipe = getRecipeById(recipeId)
  const { toggleFavorite, isFavorite } = useFavorites()

  // Helper function to get image with fallback
  const getImageSrc = (imagePath: string | undefined) => {
    return imagePath || "https://v0.dev/placeholder.svg?height=400&width=600"
  }

  if (!recipe) {
    return <div>Recipe not found</div>
  }

  return (
    <div className="max-w-md mx-auto h-screen flex flex-col bg-supercook-bg touch-manipulation">
      <div className="fixed top-0 left-0 right-0 bg-[#D98E54] border-b border-brown/10 p-4 max-w-md mx-auto z-20 safe-top">
        <div className="flex items-center justify-center relative">
          <button
            onClick={onBack}
            className="p-1 absolute left-0 touch-manipulation active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2 touch-manipulation active:scale-95 transition-transform"
          >
            <h1 className="text-lg font-serif font-bold text-white">SUPERCOOK</h1>
            <ChefHat className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-16 pb-32">
        {/* Hero Image with Heart Icon */}
        <div className="relative w-full aspect-square">
          <Image
            src={getImageSrc(recipe.image) || "/placeholder.svg"}
            alt={recipe.name}
            fill
            className="object-cover"
            priority
          />
          <button
            onClick={() => toggleFavorite(recipe.id)}
            className="absolute top-4 right-4 p-2 bg-white/90 rounded-full hover:bg-white transition-colors touch-manipulation active:scale-95"
          >
            <Heart className={`w-5 h-5 ${isFavorite(recipe.id) ? "fill-red-500 text-red-500" : "text-brown/60"}`} />
          </button>
        </div>

        {/* Recipe Info */}
        <div className="p-4">
          <h2 className="text-2xl font-serif font-bold text-brown mb-2">{recipe.name}</h2>

          <div className="flex items-center gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
            ))}
          </div>

          <div className="flex gap-4 mb-6">
            <div className="flex items-center gap-2 text-brown/70">
              <Clock className="w-5 h-5" />
              <div className="text-sm">
                <div className="font-medium">Preparation Time</div>
                <div>{recipe.time}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-brown/70">
              <Users className="w-5 h-5" />
              <div className="text-sm">
                <div className="font-medium">Serving Size</div>
                <div>
                  {recipe.servings} {recipe.servings === 1 ? "person" : "people"}
                </div>
              </div>
            </div>
          </div>

          {/* Ingredients */}
          <div className="bg-white border border-brown/10 rounded-2xl p-5">
            <h3 className="font-serif font-bold text-brown text-lg mb-3">Ingredients Required</h3>
            <ul className="space-y-2.5">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded border border-brown/20 mt-0.5 flex-shrink-0" />
                  <span className="text-brown/80 text-sm">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="fixed bottom-16 left-0 right-0 p-4 bg-supercook-bg max-w-md mx-auto z-10">
        <button
          onClick={onStartCooking}
          className="w-full bg-supercook-button text-black font-bold py-4 rounded-full hover:bg-supercook-button/90 transition-all touch-manipulation active:scale-95 min-h-[52px]"
        >
          START COOKING
        </button>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 bg-[#D98E54] border-t border-brown/10 px-8 py-3 flex justify-around max-w-md mx-auto z-20 safe-bottom">
        <button className="flex flex-col items-center gap-1 text-white touch-manipulation active:scale-95 transition-transform">
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Home</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform">
          <Heart className="w-6 h-6" />
          <span className="text-xs">Favourites</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/60 touch-manipulation active:scale-95 transition-transform">
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  )
}
