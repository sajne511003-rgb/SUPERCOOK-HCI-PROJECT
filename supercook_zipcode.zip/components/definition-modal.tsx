"use client"

import { X } from "lucide-react"
import Image from "next/image"
import { cookingTerms } from "@/lib/recipe-data"

interface DefinitionModalProps {
  term: string
  onClose: () => void
}

export function DefinitionModal({ term, onClose }: DefinitionModalProps) {
  const termData = cookingTerms[term] || {
    definition: "Definition not available",
    example: "No example available",
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-supercook-bg rounded-3xl max-w-md w-full max-h-[80vh] overflow-y-auto">
        <div className="sticky top-0 bg-supercook-bg border-b border-brown/10 p-4 flex items-center justify-between">
          <h2 className="text-xl font-serif font-bold text-brown">WHAT IS {term.toUpperCase()}?</h2>
          <button onClick={onClose} className="p-1">
            <X className="w-6 h-6 text-brown" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div className="bg-white border border-brown/10 rounded-2xl overflow-hidden">
            <div className="relative w-full aspect-video">
              <Image
                src="/sauteing-food-in-pan-cooking-technique.jpg"
                alt={`${term} technique`}
                fill
                className="object-cover"
              />
            </div>
          </div>

          <div className="bg-white border border-brown/10 rounded-2xl p-5">
            <h3 className="font-serif font-bold text-brown text-lg mb-3">Definition:</h3>
            <p className="text-brown/80 text-sm mb-4">{termData.definition}</p>
            <p className="text-brown/60 text-sm italic">Example: {termData.example}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="relative aspect-square rounded-2xl overflow-hidden border border-brown/10">
              <Image src="/vegetables-being-sauteed.jpg" alt="Example 1" fill className="object-cover" />
            </div>
            <div className="relative aspect-square rounded-2xl overflow-hidden border border-brown/10">
              <Image src="/garlic-sauteing-in-pan.jpg" alt="Example 2" fill className="object-cover" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
