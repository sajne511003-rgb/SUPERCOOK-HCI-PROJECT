"use client"

import { useState } from "react"
import { MainMenu } from "@/components/main-menu"
import { RecipeList } from "@/components/recipe-list"
import { RecipeDetail } from "@/components/recipe-detail"
import { CookingSteps } from "@/components/cooking-steps"
import { DefinitionModal } from "@/components/definition-modal"
import { IngredientSubstitution } from "@/components/ingredient-substitution"
import { SuccessScreen } from "@/components/success-screen"
import { FavoritesScreen } from "@/components/favorites-screen"
import { LoginScreen } from "@/components/login-screen"
import { ProfileScreen } from "@/components/profile-screen"
import { FavoritesProvider } from "@/lib/favorites-context"
import { getRecipeById } from "@/lib/recipe-data"

function AppContent() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [currentScreen, setCurrentScreen] = useState("login")
  const [showDefinition, setShowDefinition] = useState(false)
  const [definitionTerm, setDefinitionTerm] = useState("")
  const [showSubstitution, setShowSubstitution] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [selectedRecipeId, setSelectedRecipeId] = useState<string>("")
  const [selectedCategory, setSelectedCategory] = useState<string>("")

  const handleLogin = (user: string) => {
    setUsername(user)
    setIsLoggedIn(true)
    setCurrentScreen("main-menu")
  }

  const handleLogout = () => {
    setUsername("")
    setIsLoggedIn(false)
    setCurrentScreen("login")
    setSelectedRecipeId("")
    setSelectedCategory("")
    setCurrentStep(0)
    // Clear favorites from localStorage
    if (typeof window !== "undefined") {
      localStorage.removeItem("easy2cook-favorites")
    }
  }

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen)
    setCurrentStep(0)
  }

  const handleNavigateHome = () => {
    setCurrentScreen("main-menu")
    setSelectedRecipeId("")
    setSelectedCategory("")
    setCurrentStep(0)
  }

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category)
    handleNavigate("recipe-list")
  }

  const handleRecipeSelect = (recipeId: string) => {
    setSelectedRecipeId(recipeId)
    handleNavigate("recipe-detail")
  }

  const handleShowDefinition = (term: string) => {
    setDefinitionTerm(term)
    setShowDefinition(true)
  }

  const handleNextStep = () => {
    setCurrentStep((prev) => prev + 1)
  }

  const handlePrevStep = () => {
    setCurrentStep((prev) => Math.max(0, prev - 1))
  }

  const currentRecipe = selectedRecipeId ? getRecipeById(selectedRecipeId) : null

  if (!isLoggedIn) {
    return (
      <main className="min-h-screen bg-cream">
        <LoginScreen onLogin={handleLogin} onNavigateToSignup={() => {}} />
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-cream">
      {currentScreen === "main-menu" && (
        <MainMenu
          onNavigate={handleCategorySelect}
          onShowFavorites={() => handleNavigate("favorites")}
          onShowProfile={() => handleNavigate("profile")}
        />
      )}
      {currentScreen === "recipe-list" && (
        <RecipeList
          category={selectedCategory}
          onBack={() => handleNavigate("main-menu")}
          onSelectRecipe={handleRecipeSelect}
          onShowFavorites={() => handleNavigate("favorites")}
          onShowProfile={() => handleNavigate("profile")}
          onNavigateHome={handleNavigateHome}
        />
      )}
      {currentScreen === "favorites" && (
        <FavoritesScreen
          onBack={() => handleNavigate("main-menu")}
          onSelectRecipe={handleRecipeSelect}
          onNavigateHome={handleNavigateHome}
          onNavigateProfile={() => handleNavigate("profile")}
        />
      )}
      {currentScreen === "profile" && (
        <ProfileScreen
          username={username}
          onNavigateHome={handleNavigateHome}
          onNavigateFavorites={() => handleNavigate("favorites")}
          onMyRecipes={() => handleNavigate("favorites")}
          onLogout={handleLogout}
        />
      )}
      {currentScreen === "recipe-detail" && (
        <RecipeDetail
          recipeId={selectedRecipeId}
          onBack={() => handleNavigate("recipe-list")}
          onStartCooking={() => handleNavigate("cooking-steps")}
          onNavigateHome={handleNavigateHome}
        />
      )}
      {currentScreen === "cooking-steps" && (
        <CookingSteps
          recipeId={selectedRecipeId}
          step={currentStep}
          onNext={handleNextStep}
          onPrev={handlePrevStep}
          onShowDefinition={handleShowDefinition}
          onShowSubstitution={() => setShowSubstitution(true)}
          onComplete={() => handleNavigate("success")}
          onNavigateHome={handleNavigateHome}
        />
      )}
      {currentScreen === "success" && (
        <SuccessScreen
          recipeId={selectedRecipeId}
          recipeName={currentRecipe?.name}
          recipeImage={currentRecipe?.image}
          onDone={handleNavigateHome}
        />
      )}

      {showDefinition && <DefinitionModal term={definitionTerm} onClose={() => setShowDefinition(false)} />}

      {showSubstitution && (
        <IngredientSubstitution recipeId={selectedRecipeId} onClose={() => setShowSubstitution(false)} />
      )}
    </main>
  )
}

export default function Home() {
  return (
    <FavoritesProvider>
      <AppContent />
    </FavoritesProvider>
  )
}
