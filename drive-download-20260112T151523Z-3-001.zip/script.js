// Wait for the document to load
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('recipeSearch');
    const cards = document.querySelectorAll('.menu-card');

    // Listen for typing in the search bar
    searchInput.addEventListener('input', (e) => {
        const value = e.target.value.toLowerCase();

        cards.forEach(card => {
            // Check the text inside the span of the card
            const recipeName = card.querySelector('span').textContent.toLowerCase();
            
            // Show card if match found, otherwise hide it
            if (recipeName.includes(value)) {
                card.style.display = "flex";
            } else {
                card.style.display = "none";
            }
        });
    });
});