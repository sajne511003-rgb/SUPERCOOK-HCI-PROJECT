// --- SIGN UP FUNCTION ---
function signup() {
    // Get values from Sign Up HTML IDs
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Validation
    if (!firstName || !lastName || !email || !password) {
        alert("Please fill in all fields");
        return;
    }

    // Save to LocalStorage
    localStorage.setItem("firstName", firstName);
    localStorage.setItem("lastName", lastName);
    localStorage.setItem("email", email);
    localStorage.setItem("password", password); // Store the password

    alert("Account created successfully! Please log in.");
    window.location.href = "login.html";
}

// --- LOGIN FUNCTION ---
function handleLogin() {
    // Get values from Login HTML IDs
    const enteredEmail = document.getElementById("loginEmail").value;
    const enteredPass = document.getElementById("loginPass").value;

    // Retrieve saved data from LocalStorage
    const savedEmail = localStorage.getItem("email");
    const savedPass = localStorage.getItem("password");

    // Check if user exists
    if (!savedEmail) {
        alert("No account found. Please sign up first.");
        return;
    }

    // Compare credentials
    if (enteredEmail === savedEmail && enteredPass === savedPass) {
        localStorage.setItem("loggedIn", "true");
        window.location.href = "home.html";
    } else {
        alert("Invalid email or password");
    }
}